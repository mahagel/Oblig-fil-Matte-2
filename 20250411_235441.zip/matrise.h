#include "std_lib_facilities.h"

double normal_generator(double min, double max);
int uniform_generator(int min, int max);

template<typename Type, bool er_3d = false>
class Matrise {
public:
    /// Definerer matrise med kolonner og rader
    /// Hvis er_3d er true, definerer den en 3D matrise med dybde (Lengden av hver 3d vektor)
    size_t kolonner;
    size_t rader;
    size_t dybde = 0;
    vector<vector<Type>> data;
    vector<vector<vector<Type>>> data3d;

    //Standard konstruktør med 0 kolonner og 0 rader
    Matrise() : kolonner(0), rader(0){
        if (er_3d) {
            data3d.resize(kolonner, vector<vector<Type>>(rader, vector<Type>(dybde)));
        } else {
            data.resize(kolonner, vector<Type>(rader));
        }
    }

    //Konstruktør med kolonner og rader, og dybde hvis er_3d er true, og man kan sette første og siste kolonne med valgfro størrelse og en valgfri kolonne med valgfri dybde
    Matrise(int k, int r, int d = 0, int første_kolonne_size = -1, int siste_kolonne_size = -1, int valgfri_kolonne = -1, int valgfri_kolonne_dybde = -1)
    : kolonner(k), rader(r), dybde(d)
    {
        try {
            if (kolonner <= 0 || rader <= 0) {
                throw runtime_error("Antall kolonner og rader må være større enn 0.");
            }
        } catch (const runtime_error& e) {
            cerr << "Feil: " << e.what() << ", Mest sannsynlig ikke gyldig indeksering for kolonner og rader" << endl;
            exit(1);
        }
        if (første_kolonne_size == -1) {første_kolonne_size = rader;}
        if (siste_kolonne_size == -1) {siste_kolonne_size = rader;}
        if (valgfri_kolonne_dybde == -1) {valgfri_kolonne_dybde = d;}

        if constexpr (er_3d) {
            data3d.resize(kolonner, vector<vector<Type>>(rader, vector<Type>(dybde)));
        
            // Første kolonne (kolonne 0)
            data3d.at(0).resize(første_kolonne_size, vector<Type>(dybde));
        
            // Siste kolonne (kolonne k-1)
            data3d.at(kolonner - 1).resize(siste_kolonne_size, vector<Type>(dybde));

            // Valgfri kolonne
            for (auto& rad : data3d.at(valgfri_kolonne)) {
                rad.resize(valgfri_kolonne_dybde);
            }
        }
        else {
            // Samme
            data.resize(kolonner, vector<Type>(rader));
            data.at(0).resize(første_kolonne_size);
            data.at(kolonner - 1).resize(siste_kolonne_size);
        }
    }

    //mulighet for å generere tilfeldige tall i en gitt kolonne
    void generer_random_kolonne(int kolonne_nr, double forventningsverdi, double standardavvik)
    {
        if constexpr (er_3d){
            for (size_t r = 0; r < data3d.at(kolonne_nr).size(); r++){
                for (size_t d = 0; d < data3d.at(kolonne_nr).at(r).size(); d++){
                    data3d.at(kolonne_nr).at(r).at(d) = normal_generator(forventningsverdi, standardavvik);
                }
            }
        }
        else {
            for (size_t r = 0; r < data.at(kolonne_nr).size(); r++){
                data.at(kolonne_nr).at(r) = normal_generator(forventningsverdi, standardavvik);
            }
        }
    }
};

//Endrer operator << for å kunne skrive ut matriser
template<typename Type, bool er_3d>
ostream& operator<<(ostream& os, const Matrise<Type, er_3d>& matrise)
{
    if constexpr (er_3d){
        size_t maks_rader = 0;
        for (size_t k = 0; k < matrise.kolonner; ++k) {
            if (matrise.data3d.at(k).size() > maks_rader)
                maks_rader = matrise.data3d.at(k).size();
        }

        for (size_t r = 0; r < maks_rader; ++r) {
            for (size_t k = 0; k < matrise.kolonner; ++k) {
                if (r < matrise.data3d.at(k).size()) { // Sjekker om raden eksisterer, siden jeg har implementert at enkelte kolonner kan ha ulik størrelse
                    os << "[";
                    for (size_t d = 0; d < matrise.data3d.at(k).at(r).size(); ++d) {
                        os << matrise.data3d.at(k).at(r).at(d) << " ";
                    }
                    os << "]";
                } else {
                    os << " ";
                }
            }
            os << "\n";
        }
    }
    else {
        size_t maks_rader = 0;
        for (size_t k = 0; k < matrise.kolonner; ++k) {
            if (matrise.data.at(k).size() > maks_rader)
                maks_rader = matrise.data.at(k).size();
        }

        for (size_t r = 0; r < maks_rader; ++r) {
            for (size_t k = 0; k < matrise.kolonner; ++k) {
                if (r < matrise.data.at(k).size()) {
                    os << matrise.data.at(k).at(r) << " ";
                } else {
                    os << "  ";
                }
            }
            os << "\n";
        }
    }
    return os;
}