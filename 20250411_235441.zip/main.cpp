#include "trener.h"

using namespace std;

int main() {
    // Parametre for nettverket:
    int antall_lag = 4;
    int antall_nevroner_pr_lag = 4; 
    int antall_inputs = 2;
    int antall_outputs = 2;
    double læringsrate = 0.01;
    int batch_size = 5; // Antall treningsprøver i batchen

    // Opprett et treningssett med batch_size eksempler.
    // Vi antar at konstruktøren til Matrise fungerer slik at 'kolonner' tilsvarer antall eksempler
    Matrise<double> InputMatrise(2000, antall_inputs);
    Matrise<double> OutputMatrise(2000, antall_outputs);

    Matrise<double> inputBatch(batch_size, antall_inputs);
    Matrise<double> outputBatch(batch_size, antall_outputs);

    // Fyller input og output med verdier, egentlig ville man hentet verdiene fra en reel situasjon
    // Dette er en xor test
    for (size_t i = 0; i < InputMatrise.kolonner; i++) {
        for (size_t j = 0; j < antall_inputs; j++) {
            double randomtall1 = uniform_generator(0,1);
            double randomtall2 = uniform_generator(0,1);
            InputMatrise.data.at(i).at(j) = randomtall1;
            InputMatrise.data.at(i).at(j) = randomtall2;
        }
        if (InputMatrise.data.at(i).at(0) + InputMatrise.data.at(i).at(1) == 1){
            for (size_t k = 0; k < antall_outputs; k++) {
                OutputMatrise.data.at(i).at(k) = 1 - k;
            }
        }
        else {
            for (size_t k = 0; k < antall_outputs; k++) {
                OutputMatrise.data.at(i).at(k) = k;
            }
        }
    }

    // Bruk det første eksempelet som initial input for nettverket.
    vector<double> initialInput = InputMatrise.data.at(0);

    // Initialiser nettverket
    Nettverk nettverk(antall_lag, antall_nevroner_pr_lag, antall_inputs, antall_outputs, initialInput, læringsrate, batch_size);

    // Opprett en trener med 1000 epoker
    cout << "Input Batch:\n" << inputBatch << "\nOutput Batch:\n" << outputBatch << endl;
    Trener trener(nettverk, 500);

    // Starter treningen
    for (int i = 0; i < InputMatrise.kolonner; i += batch_size){
        for (int j = 0; j < batch_size; j++){
            inputBatch.data.at(j) = InputMatrise.data.at(i);
            outputBatch.data.at(j) = OutputMatrise.data.at(i);
        }
        trener.tren(inputBatch, outputBatch);
    }

    // Etter trening, skriv ut siste tap
    cout << "Treningen er ferdig. Endelig tap: " << trener.hentTap() << endl;

    vis_netverk_animation("nettverk_test.txt");
    remove("nettverk_test.txt");

    return 0;
}