#include "nettverk.h"

pair<Matrise<double, true>, Matrise<double>> Nettverk::backward_pass(Matrise<double> Input_batch, Matrise<double> Forventet_output_batch)
{
    //Initialiserer gradientene til vekter og bias med samme dimensjoner som vekter og bias i nettverket
    Matrise<double, true> vekter_gradienter_sum(antall_lag, antall_nevroner_pr_lag, antall_nevroner_pr_lag, antall_inputs, antall_outputs, 1, antall_inputs);
    Matrise<double> bias_gradienter_sum(antall_lag, antall_nevroner_pr_lag, 0, antall_inputs, antall_outputs);

    size_t batch_størrelse = Input_batch.kolonner;

    for (size_t i = 0; i < batch_størrelse; i++) { //Skal regne ut gradientene over en batch med inputs, for så å ta gjennomsnitt
        inputvektor = Input_batch.data.at(i);
        forventet_outputvektor = Forventet_output_batch.data.at(i);

        forward_pass(); //Forward_pass for å oppdatere input og aktiveringene

        // Feilgrad for hvert nevron i nettverket
        Matrise<double> feilgrader(antall_lag, antall_nevroner_pr_lag, 0, antall_inputs, antall_outputs);

        // Output-lagets feilgrad
        vector<double> tap_derivert = tapsfunksjon_derivert();  // For denne inputen
        for (size_t output = 0; output < antall_outputs; output++) {
            double z = nevron_matrise.data.at(antall_lag-1).at(output).z;
            feilgrader.data.at(antall_lag-1).at(output) = tap_derivert.at(output) * aktiveringsfunksjon_output_derivert(z); // Gitt av chain rule, blir litt mye å gå inn på her
        }

        // Feilgrad i skjulte lag
        for (size_t l = antall_lag - 2; l > 0; l--) { // Iterer bakover fra output-laget til input-laget, men har gjort output-laget
            for (size_t n = 0; n < nevron_matrise.data.at(l).size(); n++) { //Går igjennom hvert nevron i hvert lag
                double z = nevron_matrise.data.at(l).at(n).z; 
                double feilgrad = 0;
                for (size_t v = 0; v < nevron_matrise.data.at(l+1).size(); v++) {
                    feilgrad += vekter_matrise.data3d.at(l+1).at(v).at(n) * feilgrader.data.at(l+1).at(v);
                }
                feilgrader.data.at(l).at(n) = feilgrad * aktiveringsfunksjon_derivert(z); //Feilgraden for hvert nevron er gitt ved denne formelen
                //cout << "Feilgrad for lag " << l << ", nevron " << n << ": " << feilgrader.data.at(l).at(n) << endl;
            }
        }

        // Finner gradientene for vekter og bias i hvert lag
        // Vekter og bias for inputlaget er null, så starter fra lag 1
        for (size_t l = 1; l < antall_lag; l++) {
            for (size_t n = 0; n < nevron_matrise.data.at(l).size(); n++) {
                for (size_t v = 0; v < nevron_matrise.data.at(l-1).size(); v++) {
                    vekter_gradienter_sum.data3d.at(l).at(n).at(v) += feilgrader.data.at(l).at(n) * aktiveringer_matrise.data.at(l-1).at(v); // Gradient for vekt er gitt som feilgrad * forrige aktivering
                    //cout << "Vektorg gradient for lag " << l << ", nevron " << n << ", vekt " << v << ": " << vekter_gradienter_sum.data3d.at(l).at(n).at(v) << endl;
                }
                bias_gradienter_sum.data.at(l).at(n) += feilgrader.data.at(l).at(n); // Gradient for bias er gitt som feilgrad
                //cout << "Bias gradient for lag " << l << ", nevron " << n << ": " << bias_gradienter_sum.data.at(l).at(n) << endl;
            }
        }
    }

    // Gjennomsnitt over batchen
    for (size_t l = 1; l < antall_lag; l++) {
        for (size_t n = 0; n < nevron_matrise.data.at(l).size(); n++) {
            for (size_t v = 0; v < nevron_matrise.data.at(l-1).size(); v++) {
                vekter_gradienter_sum.data3d.at(l).at(n).at(v) /= batch_størrelse;
            }
            bias_gradienter_sum.data.at(l).at(n) /= batch_størrelse;
        }
    }

    return {vekter_gradienter_sum, bias_gradienter_sum};
}