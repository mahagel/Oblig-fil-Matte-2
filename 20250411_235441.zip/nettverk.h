#include "nevron.h"

struct Nettverk{
    int antall_lag;
    int antall_nevroner_pr_lag;
    int antall_inputs;
    int antall_outputs;
    double læringsrate;
    int batch_size;

    vector<double> inputvektor;
    vector<double> forventet_outputvektor;

    Matrise<Nevron> nevron_matrise;
    Matrise<double, true> vekter_matrise;
    Matrise<double> bias_matrise;
    Matrise<double> aktiveringer_matrise;

    double tapsfunksjon(); //Beregner tap for en inputvektor og tilhørende forventet outputvektor
    vector<double> tapsfunksjon_derivert(); // Beregner gradienter for tapet med hensyn på outputene

    double tap_etter_batch(Matrise<double> Input_batch, Matrise<double> Forventet_output_batch); // Beregn gjennomsnittlig tap etter en batch med inputs for testing av nettverket

    Nettverk() : antall_lag(0), antall_nevroner_pr_lag(0), antall_inputs(0), antall_outputs(0), læringsrate(0), batch_size(0) {} // Standard konstruktør
    //Konstruktør for nettverk
    Nettverk(int antall_lag, int antall_nevroner, int antall_inputs, int antall_outputs, vector<double> inputvektor, double læringsrate, int batch_size);
    
    void forward_pass(); // Beregner aktiveringer for alle nevroner i nettverket
    pair<Matrise<double, true>, Matrise<double>> backward_pass(Matrise<double> Input_batch, Matrise<double> Forventet_output_batch); // Beregner vekter og bias for alle nevroner i nettverket - gitt en inputbatch

    void oppdater_parametre(pair<Matrise<double, true>, Matrise<double>> vekter_og_bias, double læringsrate); //Sier seg selv
};