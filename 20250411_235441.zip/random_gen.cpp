#include "matrise.h"

// Genererer et tilfeldig tall fra en normalfordeling med gitt forventningsverdi og standardavvik
double normal_generator(double forventningsverdi, double standardavvik)
{
    random_device rd;
    default_random_engine generator(rd());
    normal_distribution<double> distribution(forventningsverdi, standardavvik);
    return distribution(generator);
}

int uniform_generator(int min, int max)
{
    random_device rd;
    default_random_engine generator(rd());
    uniform_int_distribution<int> distribution(min, max);
    return distribution(generator);
}
