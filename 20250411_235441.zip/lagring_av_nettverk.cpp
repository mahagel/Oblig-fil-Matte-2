#include "lagring_av_nettverk.h"
#include <fstream>
#include <filesystem>
#include <sstream>

// For å skrive ut vector<double> pent
ostream& operator<<(ostream& os, const vector<double>& vektor) {
    for (size_t i = 0; i < vektor.size(); i++) {
        os << std::fixed << std::setprecision(1) << vektor[i];
        if (i < vektor.size() - 1) os << " ";
    }
    return os;
}

// For å lagre ett nettverk til fil (legger til, sletter ikke det som var der fra før)
void lagre_nettverk_til_fil(const string& filename, const Nettverk& nettverk) {
    ofstream outputStream{filename, ios::app}; //Lager en ofstream for å skrive til filen, og åpner den i append-modus (Har brukt ChatGPT for å få til implementasjonen av append-modus)
    if (!outputStream.is_open()) { //Feilhåndtering for å sjekke om filen åpnes
        cout << "Kunne ikke åpne filen for skriving: " << filename << endl;
        return;
    }

    for (const auto& lag : nettverk.nevron_matrise.data) {
        for (const auto& nevron : lag) {
            outputStream << nevron.a << " " << nevron.vekter << " " << nevron.bias << "\n"; // Skriver ut aktivering, vekter og bias for hvert nevron til filen
        }
    }
    // Avslutter med å skrive ut metadata om nettverket
    outputStream << "antall_lag: " << nettverk.antall_lag << " antall_nevroner_pr_lag: " << nettverk.antall_nevroner_pr_lag << " antall_inputs: " << nettverk.antall_inputs << " antall_outputs: " << nettverk.antall_outputs << "\n";
}

Nettverk enkelt_nettverk_fra_linjer(const vector<string>& nevron_linjer, const string& meta_line) {
    Nettverk nettverk;

    istringstream meta_stream(meta_line); // Bruker istringstream for å lese inn metadata-linjen (Har brukt ChatGPT for å få til implementasjonen av istringstream)
    string temp;
    meta_stream >> temp >> nettverk.antall_lag; // For hvert tall i metadata-linjen, setter vi det i nettverket
    meta_stream >> temp >> nettverk.antall_nevroner_pr_lag;
    meta_stream >> temp >> nettverk.antall_inputs;
    meta_stream >> temp >> nettverk.antall_outputs;

    int antall_lag = nettverk.antall_lag;
    int nevroner_per_lag = nettverk.antall_nevroner_pr_lag;
    int teller = 0;

    nettverk.nevron_matrise = Matrise<Nevron> (antall_lag, nevroner_per_lag, 0, nettverk.antall_inputs, nettverk.antall_outputs); // Initialiserer nevron_matrise med antall_lag og nevroner_per_lag, fordi det er egentlig bare den jeg trenger
    
    // Første lag i nettverket
    vector<Nevron> inputlag_nevroner;
    for (int n = 0; n < nettverk.antall_inputs && teller < nevron_linjer.size(); ++n, ++teller) {
        istringstream iss(nevron_linjer.at(teller)); // Bruker istringstream for å lese inn hver linje i nevron_linjeene (Bruker ChatGPT for å få til implementasjonen av istringstream)
        double a;
        iss >> a;
        
        vector<double> vekter;
        double v;
        while (iss >> v) {
            vekter.push_back(v);
        }

        double bias = vekter.back();
        vekter.pop_back(); // Siste verdi i vekter er bias, er sånn de er skrevet i filen

        Nevron nevron;
        nevron.a = a;
        nevron.vekter = vekter;
        nevron.bias = bias;

        inputlag_nevroner.push_back(nevron);
    }

    nettverk.nevron_matrise.data.at(0) = inputlag_nevroner; // Setter inn inputlaget i nevron_matrise

    // Skjulte lag
    for (int lag = 1; lag < antall_lag - 1; ++lag) {
        vector<Nevron> lag_nevroner;
        for (int n = 0; n < nevroner_per_lag && teller < nevron_linjer.size(); ++n, ++teller) { // Bruker teller for å gå igjennom linjene i nevron_linjer
            istringstream iss(nevron_linjer.at(teller));
            double a;
            iss >> a;

            vector<double> vekter;
            double v;
            while (iss >> v) {
                vekter.push_back(v);
            }

            double bias = vekter.back();
            vekter.pop_back();

            Nevron nevron;
            nevron.a = a;
            nevron.vekter = vekter;
            nevron.bias = bias;

            lag_nevroner.push_back(nevron);
        }
        nettverk.nevron_matrise.data.at(lag) = lag_nevroner; // Setter inn lag_nevroner i nevron_matrise
    }

    // For outputlaget
    vector<Nevron> outputlag_nevroner;
    for (int n = 0; n < nettverk.antall_outputs && teller < nevron_linjer.size(); ++n, ++teller) {
        istringstream iss(nevron_linjer.at(teller)); // Har brukt ChatGPT for å få til implementasjonen av istringstream
        double a;
        iss >> a;

        vector<double> vekter;
        double v;
        while (iss >> v) {
            vekter.push_back(v);
        }

        double bias = vekter.back();
        vekter.pop_back();

        Nevron nevron;
        nevron.a = a;
        nevron.vekter = vekter;
        nevron.bias = bias;
        outputlag_nevroner.push_back(nevron);
    }

    nettverk.nevron_matrise.data.at(antall_lag - 1) = outputlag_nevroner; // Setter inn outputlag_nevroner i nevron_matrise
    return nettverk;
}

// Henter nettverk fra fil og returnerer en vector med alle nettverkene
vector<Nettverk> hent_nettverk_fra_fil(const std::string& filename) {
    std::ifstream inputStream{filename};
    if (inputStream.fail()) { // Feilhåndtering for å sjekke om filen åpnes
        std::cout << "Kunne ikke åpne filen " << filename << std::endl;
        return {};
    }

    vector<Nettverk> nettverkene;
    vector<string> buffer;
    string line;

    while (getline(inputStream, line)) {
        if (line.rfind("antall_lag:", 0) == 0) { // Sjekker om linjen starter med "antall_lag:" for å identifisere metadata-linjen
            // Debugging: Når vi finner en metadata-linje
            Nettverk nettverk = enkelt_nettverk_fra_linjer(buffer, line);
            nettverkene.push_back(nettverk);
            buffer.clear(); // Klar for neste nettverk
        } else {
            buffer.push_back(line);
        }
    }

    return nettverkene;
}
