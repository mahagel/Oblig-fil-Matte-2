#include "AnimationWindow.h"
#include "lagring_av_nettverk.h"
#include "widgets/Button.h"

void vis_netverk_animation(string filnavn);
string avrundTilDesimaler(double verdi, int desimaler);

class Animasjon_for_nettverk : public AnimationWindow {
    private:
        Button stoppknapp;
        bool skal_lukkes = false;
    public:
        Animasjon_for_nettverk(int x_pos, int y_pos, int bredde, int høyde, const string& tittel);
        bool skal_lukke() const;
        void tegn_nettverk(const Nettverk& nettverk);
        void callbackButton();
};