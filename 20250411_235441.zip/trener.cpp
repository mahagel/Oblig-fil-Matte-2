#include "trener.h"

Trener::Trener(Nettverk& nettverk, int antall_epoker)
    : nettverk(nettverk), epoker(antall_epoker), sisteTap(0.0){}

// Sier seg vel litt selv

double Trener::hentTap() const { 
    return sisteTap;
}

void Trener::tren(Matrise<double>& Input_batch, Matrise<double>& Forventet_output_batch) {
    int batch_størrelse = Input_batch.kolonner;
    
    for (int i = 0; i < batch_størrelse  * (3/2); i++) // Stokker om på rekkefølgen for at læringen skal bli mindre spesialisert på en rekkefølge
    {
        int indeks1 = uniform_generator(0, batch_størrelse - 1);
        int indeks2 = uniform_generator(0, batch_størrelse - 1);

        vector<double> mellomvektor = Input_batch.data.at(indeks1);
        Input_batch.data.at(indeks1) = Input_batch.data.at(indeks2);
        Input_batch.data.at(indeks2) = mellomvektor;

        mellomvektor = Forventet_output_batch.data.at(indeks1);
        Forventet_output_batch.data.at(indeks1) = Forventet_output_batch.data.at(indeks2);
        Forventet_output_batch.data.at(indeks2) = mellomvektor;
    }

    for (int e = 0; e < epoker; e++) {
        // Backward pass for å finne gradienter
        pair<Matrise<double, true>, Matrise<double>> gradienter = nettverk.backward_pass(Input_batch, Forventet_output_batch);

        // Oppdaterer parametere
        nettverk.oppdater_parametre(gradienter, nettverk.læringsrate);

        // Beregner tap
        double gjennomsnittTap = nettverk.tap_etter_batch(Input_batch, Forventet_output_batch);

        // Skriver ut tapet
        if ( (e + 1) % (epoker / 10) == 0 ) {
            cout << "Epoke " << e + 1 << " / " << epoker << " - Gjennomsnittlig tap: " << gjennomsnittTap << endl;
            lagre_nettverk_til_fil("nettverk_test.txt", nettverk); // Lagrer en oppdaterte verdier for vekter og biaser etter 1/10 av læringen for den gitte batchen
        }
    }
}
