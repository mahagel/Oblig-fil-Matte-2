#include "nettverk.h"

void lagre_nettverk_til_fil(const string &filename, const Nettverk& nettverk);

Nettverk enkelt_nettverk_fra_linjer(const vector<string>& nevron_linjer, const string& meta_line); // Henter ut informasjon fra fil og returnerer et nettverk

vector<Nettverk> hent_nettverk_fra_fil(const std::string &filename);