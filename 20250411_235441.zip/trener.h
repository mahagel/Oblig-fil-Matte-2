#include "nettverk_wiz.h"

class Trener {
public:
    // Konstruktør som tar en referanse til et Nettverk og antall epoker man ønsker å trene batchen
    Trener(Nettverk& nettverk, int antall_epoker = 1000);

    // Utfører treningen med inputBatch og tilhørende forventet output
    void tren(Matrise<double>& Input_batch, Matrise<double>& Forventet_output_batch);

    // Returnerer tapet fra siste epoke
    double hentTap() const;

private:
    Nettverk& nettverk;
    int epoker;
    double sisteTap;
};