#include "nettverk.h"

//Beregner tap for en inputvektor og tilhørende forventet outputvektor med minste kvadraters metode / 2 for å få en clean derivert
double Nettverk::tapsfunksjon() {
    double tap = 0;
    for (size_t output = 0; output < antall_outputs; output++){
        tap += pow(aktiveringer_matrise.data.at(antall_lag-1).at(output) - forventet_outputvektor.at(output), 2);
    }
    return tap / 2;
}

vector<double> Nettverk::tapsfunksjon_derivert() { // Beregner gradienter for tapet med hensyn på outputene
    vector<double> tap_derivert(antall_outputs, 0);
    for (size_t output = 0; output < antall_outputs; output++){
        tap_derivert.at(output) = aktiveringer_matrise.data.at(antall_lag-1).at(output) - forventet_outputvektor.at(output);
    }
    return tap_derivert;
}

double Nettverk::tap_etter_batch(Matrise<double> Input_batch, Matrise<double> Forventet_output_batch) // Beregn gjennomsnittlig tap etter en batch med inputs for testing av nettverket
{
    double tap = 0;
    for (int i = 0; i < Input_batch.kolonner; i++){
        inputvektor = Input_batch.data.at(i);
        forventet_outputvektor = Forventet_output_batch.data.at(i);
        forward_pass();
        tap += tapsfunksjon();
    }
    return tap / Input_batch.kolonner;
}

//initialiserer Nettverket
Nettverk::Nettverk(int antall_lag, int antall_nevroner, int antall_inputs, int antall_outputs, vector<double> inputvektor, double læringsrate, int batch_size) : 
    antall_lag(antall_lag), 
    antall_nevroner_pr_lag(antall_nevroner), 
    antall_inputs(antall_inputs), 
    antall_outputs(antall_outputs), 
    læringsrate(læringsrate),
    batch_size(batch_size),

    inputvektor(inputvektor),
    forventet_outputvektor(antall_outputs, 0),

    nevron_matrise(antall_lag, antall_nevroner, 0, antall_inputs, antall_outputs),
    vekter_matrise(antall_lag, antall_nevroner, antall_nevroner, antall_inputs, antall_outputs, 1, antall_inputs),
    bias_matrise(antall_lag, antall_nevroner, 0, antall_inputs, antall_outputs),
    aktiveringer_matrise(antall_lag, antall_nevroner, 0, antall_inputs, antall_outputs)
{
    // Generer tilfeldige vekter og bias
    for (size_t n = 0; n < antall_inputs; n++) {
        vekter_matrise.data3d.at(0).at(n) = vector<double>(antall_inputs, 0.0); // Inputlaget har ingen vekter
        bias_matrise.data.at(0).at(n) = 0.0; // Inputlaget har ingen bias
    }
    for(size_t l = 1; l < antall_lag; l++) {
        vekter_matrise.generer_random_kolonne(l, 0, pow(2.0 / static_cast<double> (antall_inputs), 0.5));
        bias_matrise.generer_random_kolonne(l, 0, 0.01);
    }
    forward_pass(); // Beregn aktiveringer for alle nevroner i nettverket så alt er klart til trening
}

void Nettverk::forward_pass()
{   
    // Setter inn inputvektor i nevron_matrise og aktiveringer_matrise
    for (size_t nevron = 0; nevron < antall_inputs; nevron++){
        nevron_matrise.data.at(0).at(nevron).a = inputvektor.at(nevron);
        aktiveringer_matrise.data.at(0).at(nevron) = inputvektor.at(nevron);
    }

    // Setter inn vekter og bias i nevron_matrise og aktiveringer_matrise
    for (size_t l = 1; l < antall_lag; l++) {
        for (size_t n = 0; n < nevron_matrise.data.at(l).size(); n++) {
            nevron_matrise.data.at(l).at(n) = Nevron(l, n, vekter_matrise.data3d.at(l).at(n), bias_matrise.data.at(l).at(n), aktiveringer_matrise.data.at(l-1));
        }
    }

    // Oppdaterer nevron_matrise og aktiveringer_matrise med de nye verdiene
    oppdater_Nevron_matrise(nevron_matrise, aktiveringer_matrise);
}

void Nettverk::oppdater_parametre(pair<Matrise<double, true>, Matrise<double>> vekter_og_bias, double læringsrate) {
    for (size_t l = 1; l < antall_lag; l++) {
        for (size_t n = 0; n < nevron_matrise.data.at(l).size(); n++) {
            for (size_t v = 0; v < nevron_matrise.data.at(l-1).size(); v++) { // Bruker .size() fordi input og outputlagene kan ha ulik størrelse
                if (abs(vekter_og_bias.first.data3d.at(l).at(n).at(v)) < 5){
                vekter_matrise.data3d.at(l).at(n).at(v) -= læringsrate * vekter_og_bias.first.data3d.at(l).at(n).at(v);
                }
                else {vekter_matrise.data3d.at(l).at(n).at(v) -= 0.1;}
            }
            if (abs(vekter_og_bias.second.data.at(l).at(n)) < 11){
            bias_matrise.data.at(l).at(n) -= læringsrate * vekter_og_bias.second.data.at(l).at(n);
            }
            else {bias_matrise.data.at(l).at(n) -= 0.05;}
        }
    }
    oppdater_Nevron_matrise(nevron_matrise, aktiveringer_matrise);
}