#include "nettverk_wiz.h"

string avrundTilDesimaler(double verdi, int desimaler) {
    stringstream ss;
    ss << std::fixed << std::setprecision(desimaler) << verdi;
    return ss.str();
}

void Animasjon_for_nettverk::callbackButton() {
    skal_lukkes = true;
}

Animasjon_for_nettverk::Animasjon_for_nettverk(int x_pos, int y_pos, int bredde, int høyde, const string& tittel) 
    : AnimationWindow(x_pos, y_pos, bredde, høyde, tittel), stoppknapp({bredde - 100, høyde - 50}, 80, 30, "Stopp") 
    {
    setBackgroundColor(Color::dark_slategray);
    stoppknapp.setButtonColor(Color::crimson);
    stoppknapp.setCallback([this]() {this -> callbackButton();}); // Skjønte ikke hvordan dette funker, måtte copilote til det funka
    add(stoppknapp);
    }

bool Animasjon_for_nettverk::skal_lukke() const{
    return skal_lukkes || this -> should_close(); // Bruker or siden AnimationWindow har lyst til å lukke vinduet på egne tidspunkter
}

void Animasjon_for_nettverk::tegn_nettverk(const Nettverk& nettverk)
{
    Matrise<Nevron> nevroner = nettverk.nevron_matrise;
    int bredde = this->width(); // Finner bredden til vinduet
    int høyde = this->height(); // Finner høyden til vinduet
    int avstand_x = bredde / static_cast<int>(nettverk.antall_lag + 1); // Avstanden mellom lag gitt ved antall lag for å få sentrering
    int max_nevroner = 0;
    for (const auto& lag : nevroner.data) {
        max_nevroner = max(nettverk.antall_inputs, static_cast<int> (lag.size())); // Finner størrelsen på det største laget
    }

    int minimum_radius = min(30, static_cast<int>((bredde / (1 + max_nevroner)) * 0.4)); // Ønsker i utgangspunktet at nevronene skal få størrelse etter max_nevroner, men de kan ikke bli for små

    for (int i = 0; i < nettverk.antall_lag; i++) {
        int antall_nevroner = nevroner.data.at(i).size();
        int avstand_y = høyde / static_cast<int>(1 + antall_nevroner); //Avstanden mellom nevroner gitt ved antall nevroner i laget for å få sentrering
        
        for (int j = 0; j < antall_nevroner; j++) {
            Point senter {avstand_x + avstand_x * i, avstand_y + avstand_y * j}; //Finner sentrum for nevronet i lag i, nevron j
            int radius = minimum_radius + static_cast<int>(nevroner.data.at(i).at(j).a * 5); // Finner radius basert på aktivering
            
            draw_circle(senter, radius, Color::light_sky_blue); // Tegner nevronet
            draw_text({senter.x - 20, senter.y - 15}, avrundTilDesimaler(nevroner.data.at(i).at(j).a, 2), Color::white);
            
            // Tegner vekter
            if (i > 0) {
                for (int k = 0; k < nevroner.data.at(i-1).size(); k++) { // Antall vekter for nevronet er gitt ved antall nevroner i forrige lag
                    Point forrige_senter { // Sier seg selv
                        avstand_x + avstand_x * (i-1), 
                        høyde / static_cast<int>(1 + nevroner.data[i-1].size()) * (1 + k)
                    };
                    double vekt = nevroner.data[i][j].vekter[k];
                    Color farge = (vekt > 0) ? // Setter farge indikert av verdien til nevronet
                                    (vekt > 0.5 ? Color::green : Color::yellow) :
                                    (vekt < -0.5 ? Color::red : Color::orange);
                    draw_line(forrige_senter, senter, farge); // sier seg selv
                }
            }
        }
    }
}

void vis_netverk_animation(string filnavn) {
    vector<Nettverk> nettverk_vektor = hent_nettverk_fra_fil(filnavn);
    const int bredde = 1440;
    const int høyde = 820;
    Animasjon_for_nettverk window(0, 30, bredde, høyde, "Nettverksvisualisering");

    size_t current_frame = 0;
    bool paused = true;

    while (!window.skal_lukke()) { //ChatGPT har skrevet mesteparten av denne løkken, ettersom jeg ikke kom på noen måte å implementere pause-mekanismen på
        if (window.is_key_down(KeyboardKey::RIGHT)) { //Gå framover med høyre pil
            current_frame = (current_frame + 1) % nettverk_vektor.size();
            paused = true;
            window.wait_for(0.1); // Unngår flere tastetrykk
        }
        else if (window.is_key_down(KeyboardKey::LEFT)) {
            current_frame = (current_frame > 0) ? current_frame - 1 : nettverk_vektor.size() - 1;
            paused = true;
            window.wait_for(0.1);
        }
        else if (window.is_key_down(KeyboardKey::SPACE)) { // Hvis space trykket inn, endre pause-verdien til motsatt
            paused = !paused;
            window.wait_for(0.2);
        }

        // Oppdaterer animasjon
        if (!paused) {
            current_frame = (current_frame + 1) % nettverk_vektor.size();
            window.wait_for(0.05);
        }

        // Vis statusinfo
        if (paused) {
            window.draw_text({50, 50}, "Høyre pil: neste, Venstre pil: forrige", Color::light_gray);
            window.draw_text({50, 80}, "Mellomrom: start automatisk avspilling", Color::light_gray);
        }
        window.draw_text({50, høyde - 50}, "epoke: " + to_string(current_frame+1) + "/" + to_string(nettverk_vektor.size()), Color::light_gray);
        window.tegn_nettverk(nettverk_vektor.at(current_frame));
        window.next_frame();
    }
}