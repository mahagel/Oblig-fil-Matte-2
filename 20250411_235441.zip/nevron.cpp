#include "nevron.h"
#include <iomanip>

double aktiveringsfunksjon(double z) {
    return max(0.01 * z, z); // leaky ReLU funksjon
}

double aktiveringsfunksjon_derivert(double z) {
    if (z > 0){
        return 1.0;
    } 
    else{
        return -0.01;
    } // Derivert av ReLU funksjon
}

double aktiveringsfunksjon_output(double z) {
    return 1 / (1 + exp(-z)); // Sigmoid funksjon - squisher output mellom 0 og 1
}

double aktiveringsfunksjon_output_derivert(double z) {
    double sigmoid = aktiveringsfunksjon_output(z);
    return sigmoid * (1 - sigmoid); // Derivert av sigmoid funksjon
}

Nevron::Nevron() : lag_nr(0), nevron_nr(0), a(0), z(0), bias(0), vekter() {}

Nevron::Nevron(int lag, int nevron, vector<double> vekter, double bias, vector<double> forrige_aktiveringer) //Konstruktør for nevron
: lag_nr(lag), nevron_nr(nevron), vekter(vekter), bias(bias), forrige_aktiveringer(forrige_aktiveringer) 
{
    beregn_z(); // Beregn z når nevronen opprettes
    if (lag_nr != 0) {
        a = aktiveringsfunksjon(z);
    } else {
    a = aktiveringsfunksjon_output(z); // Beregn a ved hjelp av aktiveringsfunksjonen
    }
}

void Nevron::beregn_z() {
    z = 0;
    for (size_t i = 0; i < vekter.size(); i++) {
        z += vekter.at(i) * forrige_aktiveringer.at(i); // Beregn z ved å summere vektene multiplisert med forrige aktiveringer...
    }
    z += bias; // ... og legger til bias
}

void Nevron::oppdater_nevron(vector<double> nye_forrige_aktiveringer) {
    forrige_aktiveringer = nye_forrige_aktiveringer; // Oppdater forrige aktiveringer
    beregn_z(); // Finn ny z
    a = aktiveringsfunksjon(z); // Finn ny a
}

pair<int, int> Nevron::hent_nevron_posisjon() {
    return {lag_nr, nevron_nr}; // Returner lag og nevron nummer, duh
}

ostream& operator<<(ostream& os, const Nevron& nevron) {
    os << "a = " << std::fixed << std::setprecision(2) << nevron.a << ", b = " << std::fixed << std::setprecision(2) << nevron.bias << ", vekter = [";
    for (int i = 0; i < nevron.vekter.size(); i++) {
        os << std::fixed << std::setprecision(1) << nevron.vekter.at(i);
        if (i < nevron.vekter.size() - 1) {
            os << ", "; // Legg til komma kun mellom elementer for at det skal se finere ut
        }
    }
    os << "]    ";
    return os;
}

void oppdater_Nevron_matrise(Matrise<Nevron>& Nevron_matrise, Matrise<double>& Aktiveringer) {
    for (size_t l = 1; l < Nevron_matrise.kolonner - 1; l++) {
        for (size_t n = 0; n < Nevron_matrise.data.at(l).size(); n++) {
            Nevron_matrise.data.at(l).at(n).oppdater_nevron(Aktiveringer.data.at(l-1));
            Aktiveringer.data.at(l).at(n) = Nevron_matrise.data.at(l).at(n).a;
        }
    }
    for (size_t n = 0; n < Nevron_matrise.data.at(Nevron_matrise.kolonner - 1).size(); n++) {
        Nevron_matrise.data.at(Nevron_matrise.kolonner - 1).at(n).forrige_aktiveringer = Aktiveringer.data.at(Nevron_matrise.kolonner - 2); // Oppdater forrige aktiveringer for output lag
        Nevron_matrise.data.at(Nevron_matrise.kolonner - 1).at(n).beregn_z(); // Finn ny z
        Nevron_matrise.data.at(Nevron_matrise.kolonner - 1).at(n).a = aktiveringsfunksjon_output(Nevron_matrise.data.at(Nevron_matrise.kolonner - 1).at(n).z); // Finn ny a
        Aktiveringer.data.at(Nevron_matrise.kolonner - 1).at(n) = aktiveringsfunksjon_output(Nevron_matrise.data.at(Nevron_matrise.kolonner - 1).at(n).z); 
        // Ja dette er stygt, beklager, men har ikke tenkt igjennom det før nå iog orker ikke endre det
    }
}