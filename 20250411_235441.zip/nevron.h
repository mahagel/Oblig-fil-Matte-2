#include "matrise.h"

double aktiveringsfunksjon(double z);
double aktiveringsfunksjon_derivert(double z);
double aktiveringsfunksjon_output_derivert(double z);
double aktiveringsfunksjon_output(double z);

class Nevron {
    private:
        // Hvert nevron har en posisjon i nettverket, en aktivering, en bias og vekter fra forrige lag til nevronet. Andre inititialiseringer er for å beregne aktiveringen
        int lag_nr;
        int nevron_nr;
    public: 
        double a;
        double z;
        vector<double> vekter;
        double bias;
        vector<double> forrige_aktiveringer;
        void beregn_z();

        Nevron(); // Standard konstruktør
        Nevron(int lag, int nevron, vector<double> vekter, double bias, vector<double> forrige_aktiveringer); // Konstruktør for nevron

        pair<int, int> hent_nevron_posisjon();
        void oppdater_nevron(vector<double> nye_forrige_aktiveringer);

        friend ostream& operator<<(ostream& os, const Nevron& nevron);
};

void oppdater_Nevron_matrise(Matrise<Nevron>& nevron_Matrise, Matrise<double>& Aktiveringer); // Har denne utenfor, men hadde kanskje vært bedre impelementasjon i klassen, men det er ikke så viktig.